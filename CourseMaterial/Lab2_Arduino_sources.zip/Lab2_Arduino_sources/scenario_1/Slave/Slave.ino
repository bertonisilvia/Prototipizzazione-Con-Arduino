//librerie per i moduli NRF24L01
#include <RF24.h>
#include <RF24_config.h>

//librerie per sensore di temperatura
#include <OneWire.h>
#include <DallasTemperature.h>

//inizializzazione delle variabili
//definisco il sensore collegato al pin 2
#define ONE_WIRE_BUS 2

//definisco pin a cui il buzzer è collegato
#define buzzer 3

//variabile per il sensore di corrente
const int analogIn = A0;
int mVperAmp = 185; // use 100 for 20A Module and 66 for 30A Module
int RawValue= 0;
int ACSoffset = 2500; 
double Voltage = 0;
double Amps = 0;

//utilizzo pin 7 e 8 per il chip enable e chip select
RF24 radio (7, 8);

//struct per ricevere i parametri
struct Temp_temp{
  float temperatura;
  unsigned long tempo;
}sendReq;

// Function that printf and related will use to print
int serial_putchar(char c, FILE* f) {
   if (c == '\n') serial_putchar('\r', f);
   return Serial.write(c) == 1? 0 : 1;
}
FILE serial_stdout;

//indirizzi per la pipe
const uint64_t addresses[2] = { 0xF0F0F0F0E1LL, 0xF0F0F0F0D2LL};

float temperature = 0.0;

//imposta la comunicazione per un dispositivo compatibile
OneWire oneWire(ONE_WIRE_BUS);
//passa da OneWire a DallasTemperature
DallasTemperature sensors(&oneWire);

void setup() {
  //faccio partire il monitor seriale
  Serial.begin(115200);
  delay(1000);
  //imposto il buzzer come output
  pinMode(buzzer, OUTPUT);
  Serial.println("RF24 Slave started\n");

  //faccio partire il sensore di temperature e il trasmettitore
  sensors.begin();
  radio.begin();
  
  //inizializzo su quale canale invio/ricevo i dati (1-126)
  radio.setChannel(105);

  //modifico grandezza del payload da 1 a 32 bytes
  radio.setPayloadSize(8);

  //modifico potenza di trasmissione del segnale
  //  RF24_PA_MIN=-18dBm
  //  RF24_PA_LOW=-12dBm
  //  RF24_PA_MED=-6dBM
  //  RF24_PA_HIGH=0dBm
  radio.setPALevel(RF24_PA_HIGH);

  //modifico velocità di trasmissione del segnale
  //  RF24_250KBPS per 250kbs
  //  RF24_1MBPS per 1Mbps
  //  RF24_2MBPS per 2Mbps
  radio.setDataRate( RF24_2MBPS );

  //apro la pipe per la scrittura
  radio.openWritingPipe(addresses[0]);
  //apro la read per la lettura
  radio.openReadingPipe(1, addresses[1]);

  //radio.setCRCLength(0);
  
   // Set up stdout
   fdev_setup_stream(&serial_stdout, serial_putchar, NULL, _FDEV_SETUP_WRITE);
   stdout = &serial_stdout;
   
  Serial.println("DEBUG_1");
  radio.printDetails();

}

void loop() {
  // --------------------------------------------------------------------
  // Rilevo la temperatura.
  // Invia il comando di conversione per il sensore
  sensors.requestTemperatures();


  RawValue = analogRead(analogIn);
  Voltage = (RawValue / 1024.0) * 5000; // Gets you mV
  Amps = ((Voltage - ACSoffset) / mVperAmp);

  // Restituisce la temperatura in gradi Celsius
  temperature = sensors.getTempCByIndex(0);
  // --------------------------------------------------------------------
  // Controllo se la temperature ha superato il limite.
  if(temperature < 28){
    
    radio.startListening();
    if( radio.available()){
      while (radio.available()) {
        radio.read( &sendReq.tempo, sizeof(unsigned long) );
      }
      radio.stopListening();
      // Rilevo nuovamente la temperatura prima di inviarla.
      sendReq.temperatura = temperature;
      if(!radio.write( &sendReq, sizeof(sendReq) )){
       Serial.println("Failed on sending");
     }else{
      Serial.print("Sending temperature : ");
      Serial.print(sendReq.temperatura);
      Serial.println(" C");

      //Serial.println("DEBUG_2");
      // radio.printDetails();

      }
    }
  }else{
    tone(buzzer,1000,200);
    delay(1500);
  }
}
