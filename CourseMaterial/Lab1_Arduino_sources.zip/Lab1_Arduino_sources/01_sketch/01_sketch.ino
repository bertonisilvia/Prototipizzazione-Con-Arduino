// Lato corto -> GND

# define led0 13

int status = 0;

void setup () {
  pinMode ( led0 , OUTPUT );
  digitalWrite (led0 , status );
}

void loop () {
   if ( status == LOW ) status = HIGH ;
   else status = LOW ;
   digitalWrite ( led0 , status );
   delay (200);
}
