// Lato corto GND
# define PIN_BUZZER 3
void setup (){
  pinMode ( PIN_BUZZER , OUTPUT );
}

void loop (){
  tone ( PIN_BUZZER , 1000 , 200);
  delay (500);
  noTone ( PIN_BUZZER );
  delay (1000);
  tone ( PIN_BUZZER , 750 , 300);
  delay (500);
  noTone ( PIN_BUZZER );
  delay (1000);
  tone ( PIN_BUZZER , 500 , 400);
  delay (500);
  noTone ( PIN_BUZZER );
  delay (1000);
}
